Please refer to the [Development
Guide](https://github.com/pyinstaller/pyinstaller/wiki/Development).
